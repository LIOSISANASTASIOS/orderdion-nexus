
import React from 'react';
import ProductList from './components/ProductList';

function App() {
  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-4">Souvlaki Nexus</h1>
      <ProductList />
      <footer className="mt-8 text-center text-sm text-gray-400">powered by orderdion.com</footer>
    </div>
  );
}

export default App;
