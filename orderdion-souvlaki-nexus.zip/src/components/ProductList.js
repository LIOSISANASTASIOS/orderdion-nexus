
import React from 'react';

const products = [
  { id: 1, name: "Πίτα Γύρο Χοιρινό", price: "3.00€" },
  { id: 2, name: "Πατάτες Τηγανητές", price: "2.00€" },
  { id: 3, name: "Coca Cola 330ml", price: "1.50€" }
];

function ProductList() {
  return (
    <div className="grid gap-4">
      {products.map(product => (
        <div key={product.id} className="border p-4 rounded-lg shadow">
          <h2 className="text-xl font-semibold">{product.name}</h2>
          <p className="text-gray-600">{product.price}</p>
          <button className="mt-2 bg-blue-500 text-white px-4 py-2 rounded">Προσθήκη στο καλάθι</button>
        </div>
      ))}
    </div>
  );
}

export default ProductList;
